/*
 * This file is part of UEFI GPT fdisk.
 *
 * UEFI GPT fdisk is a port of GPT fdisk to UEFI/BIOS.
 * UEFI GPT fdisk est un portage de GPT fdisk vers UEFI/BIOS.
 * Ce fichier a été initié par Bernard Burette en janvier 2014.
 *
 * All this work is copyleft Bernard Burette.
 * Gauche d'auteur Bernard Burette.
 *
 * This program is distributed under the terms of the GNU GPL version 2.
 * La diffusion de ce code est faite selon les termes de la GPL GNU version 2.
 */

/**
 * Définitions pour notre colle entre UEFI et un programme Linux.
 * Définitions pour l'appel des fonctions UEFI.
 *
 * L'appel aux fonctions UEFI se fait via une macro C définie ici.
 * Le nombre d'arguments passé à la macro est calculé automatiquement
 * via un peu de magie des macros C pour appeller la fonction efi_callX
 * appropriée.
 * Celles-ci se trouvent dans le fichier efi_stub.S dans la librairie
 * gnuefi.
 */


/* Pas de double inclusion. */
#ifndef uefi_h_INCLUDED
#define uefi_h_INCLUDED


/* Pour obtenir la définition de "struct stat64" depuis sys/stat.h
   il faut faire cela en tout premier sinon le fichier sys/types.h
   aura déjà été inclus par un autre fichier d'en-tête mais sans
   cette définition. */
#define _LARGEFILE64_SOURCE 1
#include <sys/stat.h>


/* Pour éviter des inline qui retournent des "double" ce qui n'est pas
 * autorisé en mode UEFI où la parte MMS/SSE du processeur n'est pas
 * encore initialisée. */
#undef __USE_EXTERN_INLINES
#include <stdlib.h>


/* This file is included by C++ source files */
#if defined( __cplusplus )
extern "C" {
#endif


/* GNU EFI includes */
#include <efi.h>
#include <efilib.h>


/**
 * UEFI Image Handle provided on code entry, from module start-$(ARCH).
 */
extern EFI_HANDLE UEFI_ImageHandle ;


/**
 * UEFI System Table provided on code entry, from module start-$(ARCH)
 */
extern EFI_SYSTEM_TABLE * UEFI_SystemTable ;


/**
 * Ne semble pas exister partout.
 */
extern int lltostr( char * s , int size , unsigned long long i , int base , char UpCase ) ;


/**
 * __fortify_fail() : Une erreur qui abandonne l'exécution.
 * Affiche un message puis termine l'exécution.
 * @param mess Le message.
 */
extern void __fortify_fail( const char * mess ) __attribute__((noreturn)) ;


/**
 * UEFI_call() : appelle une fonction du firmware UEFI.
 * Le premier argument est la fonction, le reste ses arguments.
 */
#define UEFI_call( fun , ... ) UEFI_call_count( __VA_ARGS__ ) \
	( fun , __VA_ARGS__ )

#define UEFI_call_count( ... ) UEFI_call_count2( \
	UEFI_call_count4( __VA_ARGS__ ) , __VA_ARGS__ )

#define UEFI_call_count2( quantite , ... ) \
	UEFI_call_count3( quantite , __VA_ARGS__ )

#define UEFI_call_count3( quantite , ... ) UEFI_call##quantite

#define UEFI_call_count4( ... ) UEFI_call_count5( __VA_ARGS__ , \
	10 , 9 , 8 , 7 , 6 , 5 , 4 , 3 , 2 , 1 , 0 )

#define UEFI_call_count5( un , deux , trois , quatre , cinq , six , sept , \
	huit , neuf , dix , onze , douze , ... ) onze

#define UEFI_call1( a0 , a1 ) efi_call1( (void*) a0 , (unsigned long) a1 )

#define UEFI_call2( a0 , a1 , a2 ) efi_call2( (void*) a0 , \
	(unsigned long) a1 , (unsigned long) a2 )

extern EFI_STATUS efi_call3( void * , unsigned long , unsigned long ,
	unsigned long ) ;
#define UEFI_call3( a0 , a1 , a2 , a3 ) efi_call3( (void*) a0 , \
	(unsigned long) a1 , (unsigned long) a2 , (unsigned long) a3 )

extern EFI_STATUS efi_call4( void * , unsigned long , unsigned long ,
	unsigned long , unsigned long ) ;
#define UEFI_call4( a0 , a1 , a2 , a3 , a4 ) efi_call4( (void*) a0 , \
	(unsigned long) a1 , (unsigned long) a2 , (unsigned long) a3 , \
	(unsigned long) a4 )

#define UEFI_call5( a0 , a1 , a2 , a3 , a4 , a5 ) efi_call5( (void*) a0 , \
	(unsigned long) a1 , (unsigned long) a2 , (unsigned long) a3 , \
	(unsigned long) a4 , (unsigned long) a5 )

#if defined( __cplusplus )
}
#endif


#endif /* uefi_h_INCLUDED */

