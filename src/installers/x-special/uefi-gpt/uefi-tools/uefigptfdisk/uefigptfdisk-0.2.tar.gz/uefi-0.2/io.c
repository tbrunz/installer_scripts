/*
 * This file is part of UEFI GPT fdisk.
 *
 * UEFI GPT fdisk is a port of GPT fdisk to UEFI/BIOS.
 * UEFI GPT fdisk est un portage de GPT fdisk vers UEFI/BIOS.
 * Ce fichier a été initié par Bernard Burette en mars 2014.
 *
 * All this work is copyleft Bernard Burette.
 * Gauche d'auteur Bernard Burette.
 *
 * This program is distributed under the terms of the GNU GPL version 2.
 * La diffusion de ce code est faite selon les termes de la GPL GNU version 2.
 */

/**
 *
 * Entrée sortie fichier ou console.
 *
 */


/* en premier */
#include "uefi.h"
#include "debug.h"

#include <errno.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <linux/fs.h>
#include <linux/hdreg.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <poll.h>


/**
 * Les différents fichiers manipulables.
 */
enum type_fd
{
	fd_libre = 0 ,
	fd_console ,
	fd_dossier ,
	fd_disque ,
	fd_fichier ,
} ;


/**
 * La structure employée derrière un descripteur de fichier
 */
struct fichier
{
	EFI_HANDLE handle ; /* le handle du fichier ou du disque */
	unsigned long long position ; /* la position dans un disque en octete */
	int mode ; /* le mode d'ouverture */
	enum type_fd type ; /* le type */
} ;


/**
 * La table des fichiers ouverts.
 * La table est accédée via l'index par fd.
 */
static struct fichier * table ;


/**
 * La taille de la table en nombre d'index.
 */
static int table_max ;


/**
 * Initialise la table des fichiers ouverts.
 */
static void init() ;


/**
 * Le numéro d'un fichier ouvert d'après son fd.
 */
static int numero( int fd )
{
	/* la table des fichiers ouverts doit exister */
	init() ;
	/* controle du numéro */
	if ( fd < 0 || fd >= table_max ) {
		badf : ;
		errno = EBADF ;
		return -1 ;
	}
	/* contrôle que l'emplacement est utilisé */
	switch ( table[ fd ]. type ) {
		case fd_libre : goto badf ;
		case fd_console : break ;
		case fd_disque : break ;
		case fd_dossier : break ;
		case fd_fichier : break ;
	}
	return fd ;
}


/**
 * N'appelle pas directement sscanf car GNU en fait un truc avec isoc99.
 */
extern int __sscanf( const char * str , const char * format , ... ) ;


/**
 * open : ouverture d'un fichier.
 */
int open64( name , mode )
	const char * name ;
	int mode ;
{
	EFI_HANDLE hand ;
	int n ;
	/* debug */
	UEFI_dprintf( D_DEBUG | D_BLKIO | D_FS , "Entre dans open64( \"%s\" , mode=%06x )\n" ,
		name , mode ) ; 
	/* la table des fichiers ouverts doit exister */
	init() ;
	/* passe "EFI_HANDLE" et "(" */
	while ( * name && name[ 0 ] != '(' ) name ++ ;
	if ( * name ) name ++ ;
	if ( * name == 0 ) {
		errno = ENOENT ;
		return -1 ;
	}
	/* après c'est le handle en hexadécimal */
	if ( __sscanf( name , "%lx" , & hand ) != 1 ) {
		errno = ENOENT ;
		return -1 ;
	}
	while ( * name && name[ 0 ] != ')' ) name ++ ;
	if ( * name ) name ++ ;
	/* trouve un numéro libre */
	for(;;) {
		for ( n = 0 ; n < table_max ; n ++ ) {
			if ( table[ n ]. type == fd_libre ) {
				/* trouvé une place */
				table[ n ]. position = 0 ;
				table[ n ]. mode = mode ;
				break ;
			}
		}
		/* trouvé un numéro */
		if ( n < table_max ) break ;
		/* il faut agrandir la table */
		__fortify_fail( "open() size" ) ;
	}
	if ( * name ) {
		/* c'est un fichier à ouvrir */
		__fortify_fail( "open() file" ) ;
	} else {
#ifdef EFI_DEBUG
		/* debug */
		if ( uefi_debug_mask( D_DEBUG | D_BLKIO ) ) {
			CHAR16 * str ;
			EFI_BLOCK_IO * block_io ;
			char txt[ 100 ] ;
			str = DevicePathToStr( DevicePathFromHandle( hand ) ) ;
			uefi_dprint_str( " " ) ;
			while ( * str ) {
				char c[ 2 ] = { * str , '\0' } ;
				uefi_dprint_str( c ) ;
				++ str ;
			}
			FreePool( str ) ;
			UEFI_call( UEFI_SystemTable-> BootServices-> HandleProtocol ,
				hand , & BlockIoProtocol , & block_io ) ;
			sprintf( txt , "\n %ld blocs de chacun %ld octets\n" ,
				block_io-> Media-> LastBlock + 1 , block_io-> Media-> BlockSize ) ;
			uefi_dprint_str( txt ) ;
			uefi_dprint_str( "--> Touche : " ) ;
			EFI_STATUS status ;
			UEFI_call( UEFI_SystemTable-> BootServices-> WaitForEvent ,
				1 , & UEFI_SystemTable-> ConIn-> WaitForKey , & status ) ;
			uefi_dprint_str( "\n" ) ;
		}
#endif
		/* c'est un disque à ouvrir */
		table[ n ]. handle = hand ;
		table[ n ]. type = fd_disque ;
	}
	return n ;
}


/**
 * L'espace dans lequel la ligne lue de la console est stocké.
 * La fonction IInput() ne permet pas de savoir si une saisie est plus
 * grande que la taille du buffer se contentant de mettre un \0 au bout
 * si c'était le cas. On va allouer un gros buffer et supposer qu'il
 * suffira dans tous les cas.
 */
static CHAR16 * ligne ;


/**
 * La position courante dans la ligne lue de la console.
 */
static CHAR16 * pos_ligne ;


/**
 * Libère le buffer de lecture en fin d'exécution.
 */
void free_ligne()
{
	free( ligne ) ;
}


/**
 * Lit une ligne sur la console.
 */
static void lit_ligne()
{
	/* tout premier appel */
	if ( ligne == NULL ) {
		ligne = malloc( 501 * sizeof( CHAR16 ) ) ;
		if ( ligne == NULL ) {
			__fortify_fail( "lit_console: ENOMEM" ) ;
		}
		atexit( free_ligne ) ;
	}
	/* appelle la fonction de librairie, elle garantif que la
	   chaîne finit par \0 */
	IInput( UEFI_SystemTable-> ConOut , UEFI_SystemTable-> ConIn ,
		(CHAR16*) "\0" , ligne , 501 ) ;
	/* IInput ne fait d'écho du saut de ligne... */
	fputc( '\n' , stdout ) ;
	/* initialise la position */
	pos_ligne = ligne ;
}


/**
 * read_console() : lecture depuis la console.
 */
static ssize_t read_console( void * buf , size_t n )
{
	size_t ret = 0 ;
	char * pos = (char *) buf ;
	/* si il faut lire une nouvelle ligne de la console */
	if ( pos_ligne == NULL ) lit_ligne() ;
	/* copie le nombre de caractères demandés (toujours 1 seul mais bon...) */
	while ( n && * pos_ligne ) {
		/* TODO: convertit UTF-16 vers UTF-8 ou pas ? */
		char c = * pos_ligne ;
		pos_ligne ++ ;
		* pos = c ;
		pos ++ ;
		n -- ;
		ret ++ ;
	}
	/* si il reste à copier c'est que la ligne lue a été finie */
	if ( n > 0 ) {
		/* il faudra relire une ligne au prochaine appel */
		pos_ligne = NULL ;
		* pos = '\n' ;
		ret ++ ;
	}
	/* le nombre d'octets lus */
	return ret ;
}


/**
 * read_disque() : lecture depuis un disque.
 */
static ssize_t read_disque( struct fichier * f , void * buf , size_t n )
{
	EFI_STATUS status ;
	EFI_DISK_IO * disk_io ;
	EFI_BLOCK_IO * block_io ;
	/* récupère les fonctions d'accès */
	status = UEFI_call( UEFI_SystemTable-> BootServices-> HandleProtocol ,
		f-> handle , & DiskIoProtocol , & disk_io ) ;
	if ( EFI_ERROR( status ) ) {
		errno = EIO ;
		return -1 ;
	}
	/* récupère les informations sur le disque */
	status = UEFI_call( UEFI_SystemTable-> BootServices-> HandleProtocol ,
		f-> handle , & BlockIoProtocol , & block_io ) ;
	if ( EFI_ERROR( status ) ) {
		errno = EIO ;
		return -1 ;
	}
	/* lit sur le disque */
	status = UEFI_call( disk_io-> ReadDisk , disk_io , block_io-> Media-> MediaId ,
		f-> position , n , buf ) ;
	if ( EFI_ERROR( status ) ) {
		errno = EIO ;
		return -1 ;
	}
	/* avance sur le disque */
	f-> position += n ;
	/* le nombre d'octets lus */
	return n ;
}


/**
 * read() : lecture.
 * @param fd Le numéro du fichier.
 * @param buf L'espace où stocker ce qui est lu.
 * @param n Le nombre d'octets maximum à lire.
 * @return Le nombre d'octets lus ou -1 en cas d'erreur (et positionne errno).
 */
ssize_t read( fd , buf , n )
	int fd ;
	void * buf ;
	size_t n ;
{
	ssize_t ret = -1 ;
	UEFI_dprintf( D_INFO , "Entre dans read( fd=%d , buf=%p , n =%ld )\n" , fd , buf , n ) ;
	/* contrôle du numéro */
	if ( numero( fd ) < 0 ) return -1 ;
	/* selon le type de fichier */
	switch( table[ fd ]. type ) {
		case fd_libre : break ;
		case fd_console : {
			ret = read_console( buf , n ) ;
			break ;
		}
		case fd_disque : {
			ret = read_disque( table + fd , buf , n ) ;
			break ;
		}
		default : {
			__fortify_fail( "read()" ) ;
			break ;
		}
	}
	UEFI_dprintf( D_INFO , "Quitte read() : %d\n" , (int) ret ) ;
	return ret ;
}


/**
 * write_console() : écrit sur la console.
 * @param out Valeur 0 pour ConOut et !=0 pour StdErr.
 * @param msg Le texte à écrire.
 * @param n Le nombre d'octets à écrire.
 */
static ssize_t write_console( EFI_HANDLE o , const char * msg , size_t n )
{
	uint16_t out[ 3 ] ;
	size_t i ;
	int err = 0 ;
	for ( i = 0 ; i < n ; ) {
		uint32_t uni ;
		uint8_t cp = (uint8_t) msg[ i ++ ] ;
		int todo ;
		if ( cp < 0x80 ) {
			uni = cp == '\t' ? ' ' : cp ;
			/* le caractère "tab" est moche */
			if ( cp == '\t' ) uni = ' ' ;
			/* le caractère "bell" n'existe pas */
			if ( cp == '\a' ) continue ;
			todo = 0 ;
		}
		else if ( cp < 0xc0 || cp > 0xf7 ) {
			/* invalid byte, msg is broken */
			break ;
		}
		else if ( cp < 0xe0 ) {
			uni = cp & 0x1f ;
			todo = 1 ;
		}
		else if ( cp < 0xf0 ) {
			uni = cp & 0x0f ;
			todo = 2 ;
		}
		else {
			uni = cp & 0x7 ;
			todo = 3 ;
		}
		while ( todo > 0 ) {
			if ( i >= n ) {
				/* missing continuation byte, msg is broken */
				err = EFAULT ;
				goto break_converter ;
			}
			cp = (uint8_t) msg[ i ++ ] ;
			if ( cp > 0xbf || cp < 0x80 ) {
				/* invalid continuation byte, msg is broken */
				err = EFAULT ;
				goto break_converter ;
			}
			uni <<= 6 ;
			uni |= cp & 0x3f ;
			todo -- ;
		}
		/* then to utf16 */
		if ( uni < 0x10000 ) {
			out[ 0 ] = (uint16_t) uni ;
			out[ 1 ] = 0 ;
		}
		else {
			uni -= 0x10000 ;
			out[ 0 ] = (uint16_t)( ( uni >> 10 ) | 0xd800 ) ;
			out[ 1 ] = (uint16_t)( ( uni & 0x3ff ) | 0xdc00 ) ;
			out[ 2 ] = 0 ;
		}
		if ( o == 0 ) {
			UEFI_call( UEFI_SystemTable-> ConOut-> OutputString ,
				UEFI_SystemTable-> ConOut , out ) ;
		} else {
			UEFI_call( UEFI_SystemTable-> StdErr-> OutputString ,
				UEFI_SystemTable-> StdErr , out ) ;
		}
		/* saut de ligne ? */
		if ( out[ 0 ] == '\n' && out[ 1 ] == 0 ) {
			out[ 0 ] = '\r' ;
			if ( o == 0 ) {
				UEFI_call( UEFI_SystemTable-> ConOut-> OutputString ,
					UEFI_SystemTable-> ConOut , out ) ;
			} else {
				UEFI_call( UEFI_SystemTable-> StdErr-> OutputString ,
					UEFI_SystemTable-> StdErr , out ) ;
			}
		}
	}
	break_converter :
	if ( i == 0 && err ) {
		/* aucun octet écrit mais une erreur */
		errno = err ;
		return -1 ;
	}
	return (ssize_t) i ;
}


/**
 * write_disque() : écriture sur un disque.
 */
static ssize_t write_disque( struct fichier * f , const void * buf , size_t n )
{
	EFI_STATUS status ;
	EFI_DISK_IO * disk_io ;
	EFI_BLOCK_IO * block_io ;

	/* récupère les fonctions d'accès */
	status = UEFI_call( UEFI_SystemTable-> BootServices-> HandleProtocol ,
		f-> handle , & DiskIoProtocol , & disk_io ) ;
	if ( EFI_ERROR( status ) ) {
		errno = EIO ;
		return -1 ;
	}
	/* récupère les informations sur le disque */
	status = UEFI_call( UEFI_SystemTable-> BootServices-> HandleProtocol ,
		f-> handle , & BlockIoProtocol , & block_io ) ;
	if ( EFI_ERROR( status ) ) {
		errno = EIO ;
		return -1 ;
	}
	/* lit sur le disque */
	status = UEFI_call( disk_io-> WriteDisk , disk_io , block_io-> Media-> MediaId ,
		f-> position , n , buf ) ;
	if ( EFI_ERROR( status ) ) {
		errno = EIO ;
		return -1 ;
	}
	/* avance sur le disque */
	f-> position += n ;
	/* le nombre d'octets écrits */
	return n ;
}


/**
 * write : écriture.
 */
ssize_t write( fd , buf , n )
	int fd ;
	const void * buf ;
	size_t n ;
{
	ssize_t ret = -1 ;
	/* contrôle du numéro */
	if ( numero( fd ) < 0 ) return -1 ;
	/* selon le type de fichier */
	switch( table[ fd ]. type ) {
		case fd_libre : break ;
		case fd_console : {
			ret = write_console( table[ fd ]. handle , buf , n ) ;
			break ;
		}
		case fd_disque : {
			ret = write_disque( table + fd , buf , n ) ;
			break ;
		}
		default : {
			__fortify_fail( "write()" ) ;
			break ;
		}
	}
	return ret ;
}


/**
 * lseek64() : positionnement.
 */
__off64_t lseek64( fd , offset , whence )
	int fd ;
	__off64_t offset ;
	int whence ;
{
	/* contrôle du numéro */
	if ( numero( fd ) < 0 ) return -1 ;
	switch ( whence ) {
		case SEEK_SET : {
			table[ fd ]. position = offset ;
			break ;
		}
		case SEEK_CUR : {
			table[ fd ]. position += offset ;
			break ;
		}
		case SEEK_END : {
			__fortify_fail( "lseek64/SEEK_END" ) ;
		}
	}
	/* c'est bon, retourne la nouvelle position >= 0 */
	return table[ fd ]. position ;
}


/**
 * ioctl : trucs divers.
 */
int ioctl( fd , request )
	int fd ;
	unsigned long int request ;
{
	va_list arg_ptr ;
	EFI_STATUS status ;
	EFI_BLOCK_IO * block_io ;
	/* UEFI_dprintf( D_INFO , "Entre dans ioctl( fd=%d , req=%lu )\n" , fd , request ) ; */
	/* contrôle du numéro */
	if ( numero( fd ) < 0 ) return -1 ;
	/* argument */
	va_start( arg_ptr , request ) ;
	/* selon le code */
	switch ( request ) {
		case BLKGETSIZE : {
			/* taille du disque en nombre de blocs de 512 octets */
			UINT64 n , s ;
			status = UEFI_call( UEFI_SystemTable-> BootServices-> HandleProtocol ,
				table[ fd ]. handle , & BlockIoProtocol , & block_io ) ;
			if ( EFI_ERROR( status ) ) {
				errno = EIO ;
				return -1 ;
			}
			/* le nombre de blocs et leur taille en octets */
			n = block_io-> Media-> LastBlock + 1 ;
			s = block_io-> Media-> BlockSize ;
			/* ajuste en nombre de blocs de 512 octets */
			while ( s < 512 ) {
				n >>= 1 ;
				s <<= 1 ;
			}
			while ( s > 512 ) {
				n <<= 1 ;
				s >>= 1 ;
			}
			/* debug
			UEFI_dprintf( D_INFO , "BLKGETSIZE : %p %lu\n" ,
				table[ fd ]. handle , (long unsigned) n ) ;
			*/
			/* l'argument est un "long unsigned" */
			* va_arg( arg_ptr , unsigned long * ) = n ;
			break ;
		}
		case BLKGETSIZE64 : {
			/* taille du disque en nombre d'octets */
			UINT64 n , s ;
			status = UEFI_call( UEFI_SystemTable-> BootServices-> HandleProtocol ,
				table[ fd ]. handle , & BlockIoProtocol , & block_io ) ;
			if ( EFI_ERROR( status ) ) {
				errno = EIO ;
				return -1 ;
			}
			/* le nombre de blocs et leur taille en octets */
			n = block_io-> Media-> LastBlock + 1 ;
			s = block_io-> Media-> BlockSize ;
			/* ajuste en nombre d'octets */
			while ( s > 1 ) {
				s >>= 1 ;
				n <<= 1 ;
			}
			/* debug
			UEFI_dprintf( D_INFO , "BLKGETSIZE64 : %p %llu\n" ,
				table[ fd ]. handle , (long long unsigned) n ) ;
			*/
			/* l'argument est 64 bits */
			* va_arg( arg_ptr , uint64_t * ) = n ;
			break ;
		}
		case BLKSSZGET : {
			/* taille d'un bloc en octets */
			UINT64 s ;
			status = UEFI_call( UEFI_SystemTable-> BootServices-> HandleProtocol ,
				table[ fd ]. handle , & BlockIoProtocol , & block_io ) ;
			if ( EFI_ERROR( status ) ) {
				errno = EIO ;
				return -1 ;
			}
			/* taille d'un bloc en octets */
			s = block_io-> Media-> BlockSize ;
			/* debug
			UEFI_dprintf( D_INFO , "BLKSSZGET : %p %u\n" ,
				table[ fd ]. handle , (unsigned) s ) ;
			*/
			/* l'argument est "unsigned" */
			* va_arg( arg_ptr , unsigned * ) = s ;
			break ;
		}
		case BLKRRPART : {
			/* relire la table des partitions */
			break ;
		}
		case HDIO_GETGEO : {
			/* retourner la géométrie du disque dans une structure spéciale */
			UINT64 n ;
			struct hd_geometry * geometry ;
			status = UEFI_call( UEFI_SystemTable-> BootServices-> HandleProtocol ,
				table[ fd ]. handle , & BlockIoProtocol , & block_io ) ;
			if ( EFI_ERROR( status ) ) {
				errno = EIO ;
				return -1 ;
			}
			/* le nombre de blocs */
			n = block_io-> Media-> LastBlock + 1 ;
			/* renseigne la structure */
			geometry = va_arg( arg_ptr , struct hd_geometry * ) ;
			memset( geometry , 0 , sizeof( struct hd_geometry ) ) ;
			geometry-> heads = 255 ;
			geometry-> sectors = 63 ;
			geometry-> cylinders = n / 63 / 255 ;
			break ;
		}
		default : {
			//TODO!
			UEFI_dprintf( D_INFO , "Entre dans ioctl( fd=%d , req=%lu )\n" , fd , request ) ;
			__fortify_fail( "ioctl" ) ;
		}
	}
	/* argument */
	va_end( arg_ptr ) ;
	/* UEFI_dprintf( D_INFO , "Quitte ioctl() : 0\n" ) ; */
	return 0 ;
}


/**
 * stat : trucs divers.
 */
int __fxstat64( ver , fd , stat_buf )
	int ver __attribute__((unused)) ;
	int fd ;
	struct stat64 * stat_buf ;
{
	/* contrôle du numéro */
	if ( numero( fd ) < 0 ) return -1 ;
	/* pour le moment ça suffit */
	memset( stat_buf , 0 , sizeof( struct stat64 ) ) ;
	//TODO!
	return 0 ;
}


/**
 * poll : TODO: utile ?
 */
int poll( fds , nfds , timeout )
	struct pollfd * fds __attribute__((unused)) ;
	nfds_t nfds __attribute__((unused)) ;
	int timeout __attribute__((unused)) ;

{
	//TODO?
	return 0 ;
}


/**
 * fsync : flush d'un fichier, inutile ici.
 */
int fsync( fd )
	int fd __attribute__((unused)) ;
{
	return 0 ;
}


/**
 * sync : flush des buffers, inutile ici.
 */
void sync()
{
}


/**
 * close : fermeture.
 */
int close( fd )
	int fd ;
{
	/* contrôle du numéro */
	if ( numero( fd ) < 0 ) return -1 ;
	/* ferme le fichier */
	switch ( table[ fd ]. type ) {
		case fd_libre :
		case fd_console :
		case fd_disque : break ;
		case fd_dossier :
		case fd_fichier : {
			/* flush + ferme */
			//TODO?
			__fortify_fail( "close() file" ) ;
		}
	}
	/* note que l'emplacement est libre */
	table[ fd ]. type = fd_libre ;
	return 0 ;
}


/**
 * Ferme tous les fichiers ouverts.
 */
static void fini()
{
	/* ferme tous les fichiers */
	for(;;) {
		table_max -- ;
		if ( table_max < 0 ) break ;
		close( table_max ) ;
	}
	/* libère la table des fichiers */
	free( table ) ;
	/* et libère le buffer de lecture de ligne */
	if ( ligne ) free( ligne ) ;
}


/**
 * Initialise la table des fichiers ouverts.
 */
static void init()
{
	/* une seule fois */
	if ( table ) return ;
	/* alloue une petite table */
	table_max = 8 ;
	table = malloc( table_max * sizeof( struct fichier ) ) ;
	if ( table == NULL ) return ;
	memset( table , 0 , table_max * sizeof( struct fichier ) ) ;
	/* note les 3 premiers */
	table[ 0 ]. type = fd_console ;
	table[ 1 ]. type = fd_console ;
	table[ 2 ]. type = fd_console ;
	table[ 2 ]. handle = (EFI_HANDLE) 1 ;
	/* fermera les fichiers en fin d'exécution */
	atexit( fini ) ;
}

