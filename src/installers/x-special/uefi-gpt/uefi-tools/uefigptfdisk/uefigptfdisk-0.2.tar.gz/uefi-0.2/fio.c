/*
 * This file is part of UEFI GPT fdisk.
 *
 * UEFI GPT fdisk is a port of GPT fdisk to UEFI/BIOS.
 * UEFI GPT fdisk est un portage de GPT fdisk vers UEFI/BIOS.
 * Ce fichier a été initié par Bernard Burette en février 2014.
 *
 * All this work is copyleft Bernard Burette.
 * Gauche d'auteur Bernard Burette.
 *
 * This program is distributed under the terms of the GNU GPL version 2.
 * La diffusion de ce code est faite selon les termes de la GPL GNU version 2.
 */

/**
 *
 * Entrée sortie FILE de stdio.
 *
 */


/* en premier */
#include "uefi.h"
#include "debug.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


/**
 * fopen : ouverture d'un flux.
 */
FILE * fopen64( name , mode )
	const char * name __attribute__((unused)) ;
	const char * mode __attribute__((unused)) ;
{
	//TODO?
	__fortify_fail( "fopen64" ) ;
}


/**
 * Le flux stdin.
 */
static struct _IO_FILE my_stdin = { ._fileno = 0 } ;
struct _IO_FILE * stdin = & my_stdin ;


/**
 * Le flux stdout.
 */
static struct _IO_FILE my_stdout = { ._fileno = 1 } ;
struct _IO_FILE * stdout = & my_stdout ;


/**
 * Le flux stderr.
 */
static struct _IO_FILE my_stderr = { ._fileno = 2 } ;
struct _IO_FILE * stderr = & my_stderr ;


/**
 * fdopen() : ouverture d'après un descripteur.
 */
FILE * fdopen( fd , mode )
	int fd __attribute__((unused)) ;
	const char * mode __attribute__((unused)) ;
{
	__fortify_fail( "fdopen" ) ;
}


/**
 * setvbuf() : choix du buffering.
 * Toutes les fonctions associées aux FILE de libmy commencent
 * par un setvbuf( f , NULL , _IONBF , 0 ) pour ne pas utiliser
 * de buffer du tout. L'appel est ici ignoré.
 */
int setvbuf( stream , buffer , mode , size )
	FILE * stream __attribute__((unused)) ;
	char * buffer __attribute__((unused)) ;
	int mode __attribute__((unused)) ;
	size_t size __attribute__((unused)) ;
{
	return 0 ;
}


#if 0

/**
 * Espace mémoire pour vfprintf().
 */
static char * my_vfprint_buf ;


/**
 * Taille de l'espace mémoire pour vfprintf().
 */
static size_t my_vfprint_buf_len ;


/**
 * Libère my_vfprint_buf.
 */
static void free_my_vfprint_buf()
{
	free( my_vfprint_buf ) ;
}


/**
 * vfprintf() : écriture d'un message d'après un format et des valeurs.
 */
int vfprintf( stream , format , args )
	FILE * stream ;
	const char * format ;
	va_list args ;
{
	size_t l ;
	if ( my_vfprint_buf == NULL ) {
		my_vfprint_buf_len = 256 ;
		my_vfprint_buf = (char *) malloc( my_vfprint_buf_len ) ;
		if ( my_vfprint_buf == NULL ) {
			return -1 ;
		}
		atexit( free_my_vfprint_buf ) ;
	}
	for (;;) {
		l = vsnprintf( my_vfprint_buf , my_vfprint_buf_len , format , args ) ;
		if ( l >= my_vfprint_buf_len ) {
			my_vfprint_buf_len <<= 1 ;
			my_vfprint_buf = (char *) realloc( my_vfprint_buf , my_vfprint_buf_len ) ;
			if ( my_vfprint_buf == NULL ) {
				return -1 ;
			}
		} else {
			break ;
		}
	}
	return write( stream-> _fileno , my_vfprint_buf , l ) ;
}
#endif

