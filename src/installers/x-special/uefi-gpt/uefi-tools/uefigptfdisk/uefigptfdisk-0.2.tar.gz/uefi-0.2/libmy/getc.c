/*
 * This file is part of UEFI GPT fdisk.
 *
 * UEFI GPT fdisk is a port of GPT fdisk to UEFI/BIOS.
 * UEFI GPT fdisk est un portage de GPT fdisk vers UEFI/BIOS.
 * Ce fichier a été initié par Bernard Burette en janvier 2014.
 * Ce fichier est récupéré soit de "GNU libc" soit de "dietlibc"
 * soit encore il a été créé de toutes pièces.
 *
 * All this work is copyleft Bernard Burette.
 * Gauche d'auteur Bernard Burette.
 *
 * This program is distributed under the terms of the GNU GPL version 2.
 * La diffusion de ce code est faite selon les termes de la GPL GNU version 2.
 */

#include "libmy.h"
#include <stdio.h>

#ifdef getc
# undef getc
#endif

#define GETC_UNGETC 0x100

int ungetc( c , stream )
	int c ;
	FILE * stream ;
{
	setvbuf( stream , NULL , _IONBF , 0 ) ;
	if ( c == EOF ) return EOF ;
	if ( stream-> _flags2 & GETC_UNGETC ) {
		return EOF ;
	}
	stream -> _shortbuf[ 0 ] = (char) c ;
	stream-> _flags2 |= GETC_UNGETC ;
	return c ;
}

int getc( stream )
	FILE * stream __attribute__((unused)) ;
{
	char c ;
	setvbuf( stream , NULL , _IONBF , 0 ) ;
	if ( stream-> _flags2 & GETC_UNGETC ) {
		c = stream -> _shortbuf[ 0 ] ;
		stream-> _flags2 &= ~ GETC_UNGETC ;
	} else {
		if ( read( stream-> _fileno , & c , 1 ) != 1 ) {
			return EOF ;
		}
	}
	return (unsigned char) c ;
}

