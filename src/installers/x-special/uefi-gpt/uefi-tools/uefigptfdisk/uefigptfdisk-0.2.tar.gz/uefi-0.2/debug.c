/*
 * This file is part of UEFI GPT fdisk.
 *
 * UEFI GPT fdisk is a port of GPT fdisk to UEFI/BIOS.
 * UEFI GPT fdisk est un portage de GPT fdisk vers UEFI/BIOS.
 * Ce fichier a été initié par Bernard Burette en janvier 2014.
 *
 * All this work is copyleft Bernard Burette.
 * Gauche d'auteur Bernard Burette.
 *
 * This program is distributed under the terms of the GNU GPL version 2.
 * La diffusion de ce code est faite selon les termes de la GPL GNU version 2.
 */

/**
 *
 * Affichage de messages pour le déverminage.
 *
 */


/* en premier */
#include "uefi.h"
#include "debug.h"
#include <efi.h>
#include <efilib.h>

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>


#ifdef EFI_DEBUG


/**
 * Le masque de debug actuel.
 * Tous les bits ne sont pas utilisés ici donc la valeur -1 indique que ce
 * module n'a pas encore été initialisé.
 * De plus cela forcera l'appel à la fonction uefi_debug_mask() lors du
 * premier emploi de la macro UEFI_dprintf().
 */
unsigned UEFI_debug_mask = -1 ;


/*
 * Contrôle le masque passé avec le masque de debug actuel.
 * Retourne vrai uniquement si tous les bits du masque passé sont
 * présents dans le masque.
 */
int uefi_debug_mask( unsigned mask )
{
	// la valeur est niv_inconnu au tout premier appel
	if ( UEFI_debug_mask == (unsigned) -1 ) {
		//TODO: recupère la variable
		UEFI_debug_mask = -1 ;
		// initialize
		if ( UEFI_debug_mask & D_DEBUG ) UEFI_debug_mask |= D_INFO ;
		if ( UEFI_debug_mask & D_INFO ) UEFI_debug_mask |= D_WARN ;
		if ( UEFI_debug_mask & D_WARN ) UEFI_debug_mask |= D_ERROR ;
		if ( ! ( UEFI_debug_mask & D_ERROR ) ) UEFI_debug_mask = 0 ;
		/* chargement du code ça va */
		UEFI_debug_mask &= ~D_INIT ;
		/* malloc et free ça va */
		UEFI_debug_mask &= ~D_POOL ;
	}
	// la macro a contrôlé qu'un bit au moins est présent
	// il reste à contrôler que le niveau est le bon
	return ( UEFI_debug_mask | mask ) == UEFI_debug_mask ;
}


/*
 * Écrit un décimal sans signe sur la console.
 */
static int uefi_dprint_udec( v )
	uint64_t v ;
{
	/* le plus grand uint64_t est 18_446_744_073_709_551_615 de 20 caractères */
	char out[ 20 ] ;
	size_t p = 20 ;
	while ( v ) {
		int val = '0' + ( v % 10 ) ;
		out[ -- p ] = val ;
		v /= 10 ;
	}
	if ( p == 20 ) out[ -- p ] = '0' ;
	return write( 2 , out + p , 20 - p ) ;
}


/* prototype */
int uefi_dprint_str( const char * s ) ;


/*
 * Écrit un décimal signé sur la console.
 */
static int uefi_dprint_dec( v )
	int64_t v ;
{
	/* ne marche sans doute pas pour le plus petit uint64_t -9_223_372_036_854_775_808 */
	if ( v < 0 ) {
		uefi_dprint_str( "-" ) ;
		v = - v ;
	}
	return uefi_dprint_udec( (uint64_t) v ) ;
}


/**
 * Compteur du nombre de "Entre dans "
 */
static int compt ;


/**
 * Écrit la chaîne passée sur la console.
 */
int uefi_dprint_str( s )
	const char * s ;
{
	int ret = 0 ;
	if ( s[ 0 ] == 'E' && s[ 1 ] == 'n' && s[ 2 ] == 't' && s[ 3 ] == 'r' && s[ 4 ] == 'e' &&
		s[ 5 ] == ' ' && s[ 6 ] == 'd' && s[ 7 ] == 'a' && s[ 8 ] == 'n' && s[ 9 ] == 's' &&
		s[ 10 ] == ' ' )
	{
		char c = ']' ;
		compt ++ ;
		ret += uefi_dprint_dec( compt ) ;
		ret += write( 2 , & c , 1 ) ;
	}
	ret += write( 2 , s , strlen( s ) ) ;
	return ret ;
}


#endif /* EFI_DEBUG */

